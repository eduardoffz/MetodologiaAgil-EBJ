package com.btech.gerenciamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
